INSERT useranswerinfo SET userid=?,nkbn=?,yearmonth=?,questionno=?,chooseanswer=?,correct=?,fraction=?,createtime=?,updatetime=?
