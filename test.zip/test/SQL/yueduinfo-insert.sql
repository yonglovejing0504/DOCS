INSERT yueduinfo SET nkbn=?,yearmonth=?,questionno=?,readid=?,readcomment=?,createtime=?,updatetime=?
