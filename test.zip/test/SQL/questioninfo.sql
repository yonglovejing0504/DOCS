CREATE TABLE questioninfo(    nkbn                                          CHAR(1) NOT NULL,
    yearmonth                                     CHAR(6) NOT NULL,
    problemkbn                                    CHAR(1),
    problemno                                     VARCHAR(2),
    readid                                        CHAR(2),
    questionno                                    VARCHAR(3) NOT NULL,
    questioncontent                               VARCHAR(200),
    choice1                                       VARCHAR(100),
    choice2                                       VARCHAR(100),
    choice3                                       VARCHAR(100),
    choice4                                       VARCHAR(100),
    correct                                       CHAR(1),
    analysis                                      VARCHAR(200),
    fraction                                      NUMERIC(3),
    createtime                                    TIMESTAMP,
    updatetime                                    TIMESTAMP,
    PRIMARY KEY (nkbn,yearmonth,questionno)
);

COMMENT ON COLUMN questioninfo.nkbn               IS 'N1N5�敪';
COMMENT ON COLUMN questioninfo.yearmonth          IS '�N��';
COMMENT ON COLUMN questioninfo.problemkbn         IS '���啪��';
COMMENT ON COLUMN questioninfo.problemno          IS '���^�C�g��ID';
COMMENT ON COLUMN questioninfo.readid             IS '�ǉ�ID';
COMMENT ON COLUMN questioninfo.questionno         IS '���A��';
COMMENT ON COLUMN questioninfo.questioncontent    IS '�����e';
COMMENT ON COLUMN questioninfo.choice1            IS '�I����1';
COMMENT ON COLUMN questioninfo.choice2            IS '�I����2';
COMMENT ON COLUMN questioninfo.choice3            IS '�I����3';
COMMENT ON COLUMN questioninfo.choice4            IS '�I����4';
COMMENT ON COLUMN questioninfo.correct            IS '����';
COMMENT ON COLUMN questioninfo.analysis           IS '���';
COMMENT ON COLUMN questioninfo.fraction           IS '�|�C���g';
COMMENT ON COLUMN questioninfo.createtime         IS '�o�^����';
COMMENT ON COLUMN questioninfo.updatetime         IS '�X�V����';

COMMENT ON TABLE  questioninfo                    IS '�����';
