CREATE TABLE codeinfo(    code                                          CHAR(3) NOT NULL,
    name                                          VARCHAR(30) NOT NULL,
    CODE1                                         VARCHAR(20),
    CODE2                                         VARCHAR(20),
    CODE3                                         VARCHAR(20),
    CODE4                                         VARCHAR(20),
    id                                            CHAR(1) NOT NULL,
    data                                          VARCHAR(20) NOT NULL,
    PRIMARY KEY (code,id)
);

COMMENT ON COLUMN codeinfo.code                   IS '�敪ID';
COMMENT ON COLUMN codeinfo.name                   IS '�敪����';
COMMENT ON COLUMN codeinfo.CODE1                  IS '�R�[�h1';
COMMENT ON COLUMN codeinfo.CODE2                  IS '�R�[�h2';
COMMENT ON COLUMN codeinfo.CODE3                  IS '�R�[�h3';
COMMENT ON COLUMN codeinfo.CODE4                  IS '�R�[�h4';
COMMENT ON COLUMN codeinfo.id                     IS 'ID';
COMMENT ON COLUMN codeinfo.data                   IS '�l';

COMMENT ON TABLE  codeinfo                        IS '�敪ID���';
