INSERT userinfo SET userid=?,password=?,usernm=?,phoneno=?,mail=?,sexid=?,img=?,mailcheck=?,phonecheck=?,createtime=?,updatetime=?
