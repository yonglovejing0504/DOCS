CREATE TABLE useranswerinfo(    userid                                        VARCHAR(60) NOT NULL,
    nkbn                                          CHAR(1) NOT NULL,
    yearmonth                                     CHAR(6) NOT NULL,
    questionno                                    VARCHAR(3) NOT NULL,
    chooseanswer                                  CHAR(1),
    correct                                       CHAR(1),
    fraction                                      NUMERIC(3),
    createtime                                    TIMESTAMP,
    updatetime                                    TIMESTAMP,
    PRIMARY KEY (userid,nkbn,yearmonth,questionno)
);

COMMENT ON COLUMN useranswerinfo.userid           IS '���[�UID';
COMMENT ON COLUMN useranswerinfo.nkbn             IS 'N1N5�敪';
COMMENT ON COLUMN useranswerinfo.yearmonth        IS '�N��';
COMMENT ON COLUMN useranswerinfo.questionno       IS '���A��';
COMMENT ON COLUMN useranswerinfo.chooseanswer     IS '�I����';
COMMENT ON COLUMN useranswerinfo.correct          IS '����';
COMMENT ON COLUMN useranswerinfo.fraction         IS '�|�C���g';
COMMENT ON COLUMN useranswerinfo.createtime       IS '�o�^����';
COMMENT ON COLUMN useranswerinfo.updatetime       IS '�X�V����';

COMMENT ON TABLE  useranswerinfo                  IS '�p?���ď�?';
