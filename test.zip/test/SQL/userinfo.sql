CREATE TABLE userinfo(    userid                                        VARCHAR(60) NOT NULL,
    password                                      VARCHAR(60) NOT NULL,
    usernm                                        VARCHAR(20) NOT NULL,
    phoneno                                       CHAR(11),
    mail                                          VARCHAR(60) NOT NULL,
    sexid                                         CHAR(1),
    img                                           VARCHAR(60),
    mailcheck                                     CHAR(1),
    phonecheck                                    CHAR(1),
    createtime                                    TIMESTAMP,
    updatetime                                    TIMESTAMP,
    PRIMARY KEY (userid)
);

COMMENT ON COLUMN userinfo.userid                 IS '���[�UID';
COMMENT ON COLUMN userinfo.password               IS '�p�X���[�h';
COMMENT ON COLUMN userinfo.usernm                 IS '���[�U��';
COMMENT ON COLUMN userinfo.phoneno                IS '�g�єԍ�';
COMMENT ON COLUMN userinfo.mail                   IS '���[��';
COMMENT ON COLUMN userinfo.sexid                  IS '����ID';
COMMENT ON COLUMN userinfo.img                    IS '�l�ʐ^';
COMMENT ON COLUMN userinfo.mailcheck              IS '���[���m�F�t���O';
COMMENT ON COLUMN userinfo.phonecheck             IS '�g�ъm�F�t���O';
COMMENT ON COLUMN userinfo.createtime             IS '�o�^����';
COMMENT ON COLUMN userinfo.updatetime             IS '�X�V����';

COMMENT ON TABLE  userinfo                        IS '���[�U���';
