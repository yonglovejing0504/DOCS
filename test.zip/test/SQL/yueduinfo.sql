CREATE TABLE yueduinfo(    nkbn                                          CHAR(1) NOT NULL,
    yearmonth                                     CHAR(6) NOT NULL,
    questionno                                    VARCHAR(3) NOT NULL,
    readid                                        CHAR(2) NOT NULL,
    readcomment                                   VARCHAR(1000) NOT NULL,
    createtime                                    TIMESTAMP,
    updatetime                                    TIMESTAMP,
    PRIMARY KEY (nkbn,yearmonth,questionno,readid)
);

COMMENT ON COLUMN yueduinfo.nkbn                  IS 'N1N5�敪';
COMMENT ON COLUMN yueduinfo.yearmonth             IS '�N��';
COMMENT ON COLUMN yueduinfo.questionno            IS '���A��';
COMMENT ON COLUMN yueduinfo.readid                IS '�ǉ�ID';
COMMENT ON COLUMN yueduinfo.readcomment           IS '�ǉ���e';
COMMENT ON COLUMN yueduinfo.createtime            IS '�o�^����';
COMMENT ON COLUMN yueduinfo.updatetime            IS '�X�V����';

COMMENT ON TABLE  yueduinfo                       IS '??������?';
